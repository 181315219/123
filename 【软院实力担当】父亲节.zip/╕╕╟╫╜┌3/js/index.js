var Fnum = 0;
var showH = $(".wrap").children("div").height();
var lenA = $(".wrap").children("div").length;
var Judge = false;
$(window).on("resize", function() {
    showH = $(".wrap").children("div").height();
    $(".wrap").scrollTop(Fnum * showH)
});
//绑定鼠标滚动事件
function Page() {
    $(".wrap").on("mousewheel DOMMouseScroll", 
    function(e) {
        e = e.originalEvent || window.event.originalEvent;
        if ($(".wrap").scrollTop() != Fnum * showH) {
            return
        }
        scrollFunc(e);
        reset()
    })
}Page();
//键盘上下键
$(document).keydown(function(e) {
    if (e.keyCode == 38) {
        Judge = true;
        reset()
    }
    if (e.keyCode == 40) {
        Judge = false;
        reset()
    }
});
function reset() {
    if (Judge) {
        Fnum--
    } else {
        Fnum++
    }
    if (Fnum > lenA - 1) {
        Fnum = lenA - 1
    }
    if (Fnum < 0) {
        Fnum = 0
    }
    resetA()
}
function resetA() {
	Email();
	Ball();
    $(".pag div").eq(Fnum).addClass("pag-show").siblings().removeClass("pag-show");
	setTimeout(function(){
		$(".wrap").stop().animate({
	        "scrollTop": Fnum * showH
	    },500)
	},300)
}
//魔法球
function Ball() {
	if (Fnum == 2) {
		$('.magic-ball div').css({
			'transition-delay': '1s'
		})
		$('.magic-ball div').eq(0).css({
			'top': '20%',
			'left': '20%',
		})
		$('.magic-ball div').eq(1).css({
			'top': '20%',
			'left': '44%',
		})
		$('.magic-ball div').eq(2).css({
			'top': '20%',
			'right': '18%',
		})
		$('.magic-ball div').eq(3).css({
			'bottom': '35%',
			'left': '32%',
		})
		$('.magic-ball div').eq(4).css({
			'bottom': '35%',
			'right': '30%',
		})
	} else {
		$('.magic-ball div').css({
			'transition-delay': '0s'
		})
		$('.magic-ball div').eq(0).css({
			'top': '-170px',
			'left': '-170px',			
		})
		$('.magic-ball div').eq(1).css({
			'top': '-170px',
			'left': '44%',
		})
		$('.magic-ball div').eq(2).css({
			'top': '-170px',
			'right': '-170px',
		})
		$('.magic-ball div').eq(3).css({
			'bottom': '-170px',
			'left': '-170px',
		})
		$('.magic-ball div').eq(4).css({
			'bottom': '-170px',
			'right': '-170px',
		})
	}
}Ball();
//邮件
function Email() {
	if (Fnum == 5) {
		$('.mail2').css({
			'bottom' : '0px',
			'transition-delay': '1s'
		})
		$('.mail1').css({
			'bottom' : '90px',
			'transition-delay': '1.7s'
		})
	} else {
		$('.mail2').css({
			'bottom' : '-377px',
			'transition-delay': '0s'
		})	
		$('.mail1').css({
			'bottom' : '-392px',
			'transition-delay': '0s'
		})		
	}
}Email();

//判断滚动方向
function scrollFunc(e) {
    if (e.wheelDelta) {
        if (e.wheelDelta > 0) {
            Judge = true
        }
        if (e.wheelDelta < 0) {
            Judge = false
        }
    } else {
        if (e.detail) {
            if (e.detail > 0) {
                Judge = false
            }
            if (e.detail < 0) {
                Judge = true
            }
        }
    }
}
//链接点
$(".pag div").on("click", function() {
    var indexB = $(this).index();
    Fnum = indexB;
    resetA()
});

//手风琴
$(function() {
    $('#accordion > li').hover(
        function () {
            var $this = $(this);
            $this.stop().animate({'width':'480px'},500);
            $('.heading', $this).stop(true,true).fadeOut();
            $('.bgwhite', $this).stop(true,true).slideDown(500);
            $('.description', $this).stop(true,true).fadeIn();
        },
        function () {
            var $this = $(this);
            $this.stop().animate({'width':'115px'},1000);
            $('.heading', $this).stop(true,true).fadeIn();
            $('.description', $this).stop(true,true).fadeOut(500);
            $('.bgwhite', $this).stop(true,true).slideUp(700);
        }
    );
});
bigMove('.new-box>img')
//大图渐变 （添加类名即可）
function bigMove(sub) {
    var timer = setInterval(shadow, 2000);
    var imgIndex = 0;
    function shadow() {
        $(sub).eq(imgIndex).fadeIn(1000).siblings("img").fadeOut(1000);
        imgIndex++;
        if (imgIndex == $(sub).length) {
            imgIndex = 0
        }
    }
    $('.sma-pic img').on('click', function() {
    	clearInterval(timer)
		var _index = $(this).index();
		imgIndex = _index;
		$(sub).eq(imgIndex).fadeIn(1000).siblings("img").fadeOut(1000);
		timer = setInterval(shadow, 2000);
	})
}